# বিল্বনারায়ণ মোটর বাইন্ডিং এন্ড রিপিয়ার শপ — Website

এই ফোল্ডারের সব ফাইল একসাথে GitHub Pages repository-তে আপলোড করুন।

ফাইল:
- index.html
- qr-code.png
- images/ (logo ও কাজের ছবি)

Website URL:
https://sajalvai06-ops.github.io/Sajal-work/

QR code-টি এই website URL-এ নিয়ে যাবে।
